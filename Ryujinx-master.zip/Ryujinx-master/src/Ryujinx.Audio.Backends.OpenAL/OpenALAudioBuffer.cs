namespace Ryujinx.Audio.Backends.OpenAL
{
    class OpenALAudioBuffer
    {
        public int BufferId;
        public ulong DriverIdentifier;
        public ulong SampleCount;
    }
}
