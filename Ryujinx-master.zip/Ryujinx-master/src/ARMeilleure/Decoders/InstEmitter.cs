using ARMeilleure.Translation;

namespace ARMeilleure.Decoders
{
    delegate void InstEmitter(ArmEmitterContext context);
}
