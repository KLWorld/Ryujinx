namespace ARMeilleure.Decoders
{
    enum RegisterSize
    {
        Int32,
        Int64,
        Simd64,
        Simd128,
    }
}
