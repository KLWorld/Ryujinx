namespace ARMeilleure.Decoders
{
    interface IOpCodeSimd : IOpCode
    {
        int Size { get; }
    }
}
