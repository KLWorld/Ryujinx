namespace ARMeilleure.State
{
    public enum PState
    {
        TFlag = 5,
        EFlag = 9,
        GE0Flag = 16,
        GE1Flag = 17,
        GE2Flag = 18,
        GE3Flag = 19,
        QFlag = 27,
        VFlag = 28,
        CFlag = 29,
        ZFlag = 30,
        NFlag = 31,
    }
}
