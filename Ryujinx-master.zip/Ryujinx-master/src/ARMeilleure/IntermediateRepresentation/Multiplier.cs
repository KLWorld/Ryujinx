namespace ARMeilleure.IntermediateRepresentation
{
    enum Multiplier
    {
        x1 = 0,
        x2 = 1,
        x4 = 2,
        x8 = 3,
        x16 = 4,
    }
}
