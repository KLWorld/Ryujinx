namespace ARMeilleure.State
{
    enum ExecutionMode
    {
        Aarch32Arm = 0,
        Aarch32Thumb = 1,
        Aarch64 = 2,
    }
}
