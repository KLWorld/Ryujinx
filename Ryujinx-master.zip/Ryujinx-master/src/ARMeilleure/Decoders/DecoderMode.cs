namespace ARMeilleure.Decoders
{
    enum DecoderMode
    {
        MultipleBlocks,
        SingleBlock,
        SingleInstruction,
    }
}
