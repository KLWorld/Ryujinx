namespace ARMeilleure.State
{
    enum FPType
    {
        Nonzero,
        Zero,
        Infinity,
        QNaN,
        SNaN,
    }
}
