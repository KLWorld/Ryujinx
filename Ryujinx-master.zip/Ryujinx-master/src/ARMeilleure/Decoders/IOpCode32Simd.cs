namespace ARMeilleure.Decoders
{
    interface IOpCode32Simd : IOpCode32, IOpCodeSimd { }
}
